# ABUS Overseas — Checkpoint (Final)

## Files to upload to GitHub Pages (all in repo root):
- index.html
- services.html  
- destinations.html
- header.html        ← shared nav component
- footer.html        ← shared footer + WhatsApp button
- styles.css         ← shared CSS (nav, footer, responsive)
- main.js            ← shared JS (nav, carousel, tabs, forms)
- components.js      ← loads header.html + footer.html dynamically
- robots.txt
- sitemap.xml

## Architecture:
Each page loads:
  <link rel="stylesheet" href="styles.css">   ← shared styles
  <style>..page-specific CSS..</style>        ← page-only styles
  <script src="main.js">                      ← shared JS
  <script src="components.js">               ← injects header + footer
