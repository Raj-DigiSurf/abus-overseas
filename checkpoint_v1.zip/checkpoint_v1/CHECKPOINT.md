# ABUS Overseas — Checkpoint v1
Date: 2026-03-19

## What's fixed in this checkpoint:
- Git merge conflict markers resolved in all HTML files
- CSS style blocks cleaned: single :root, no misplaced CSS inside media queries
- Mobile hamburger menu working on all pages (hamburger shows at 768px)
- Duplicate media query blocks removed
- Inline nav/footer replaced by header.html/footer.html components
- Truncated files restored with proper </body></html> closing tags
- Hero image removed from index.html hero-visual
- Duplicate carousel goTo() function removed from services.html
- .si grid stacks to single column at 960px on services.html
- .ccard-hero conflicting rules consolidated in destinations.html
- All flag emojis replaced with flagcdn.com images
- JSON-LD schema valid on all pages

## Files included:
- index.html       — Homepage
- services.html    — Services page
- destinations.html — Destinations page
- header.html      — Shared nav component
- footer.html      — Shared footer + WhatsApp button
- components.js    — Component loader script
- robots.txt       — SEO robots file
- sitemap.xml      — SEO sitemap

## How to restore:
Upload all files to GitHub Pages repository root.
